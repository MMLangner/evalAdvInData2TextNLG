from django.urls import path

from . import views

app_name = 'evalAdv'
urlpatterns = [
    path('', views.index, name='index'),
    path('intro', views.intro, name='intro'),
    path('invalid', views.invalid, name="invalid"),
    path('prepare', views.prepare, name="prepare"),
    path('sessions', views.sessions, name='sessions'),
    path('get_user_input', views.get_user_input, name="get_user_input"),
    path('combined_session', views.combined_session, name='combined_session'),
    path('get_combined_session_input', views.get_combined_session_input, name='get_combined_session_input'),
    path('finished', views.finished, name="finished"),
]