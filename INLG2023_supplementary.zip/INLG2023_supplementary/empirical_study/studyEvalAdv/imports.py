import csv
import pandas as pd

def load_csv_items(filename, object_constructor):

    items = pd.read_csv(filename)

    allObjects = []
    for index, row in items.iterrows():

        this_dict = {}
        for col in items.columns:
            colt = col.replace(" ", "")
            this_dict[colt] = row[col]
        
        print(this_dict)
        this_object = object_constructor(**this_dict)
        allObjects.append(this_object)

            

    return allObjects
    




